package footsiebot.databasecore;

public class DatabaseCore implements Database {

  public boolean storeScraperResults(ScrapeResult sr) {

  }

  public boolean storeQuery(ParseResult pr, DateTime date) {

  }

  public String[] getFTSE(ParseResult pr) {

  }

  private String convertScrapeResult(ScrapeResult sr) {

  }

  private String convertQuery(ParseResult pr, DateTime date) {

  }

  private String convertFTSEQuery(ParseResult pr) {

  }

  private Company[] getAICompany() {

  }

  private Company[] getAIGroup() {

  }

  private IntentData getIntentForCompany() {

  }

  private void storeAICompanies(Company[] companies) {

  }

  private void storeAIGroups(Group[] groups) {
    
  }



}
