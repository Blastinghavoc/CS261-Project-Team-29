

public class DataGatheringCore implements DataGathering {
  private WebScraper webScraper;
  private NewsScraper newsScraper;



  public ScrapeResult getData() {

  }

  public Article[] getNews(String company) {

  }

  public Article[] getNews(String[] companies) {

  }






}
