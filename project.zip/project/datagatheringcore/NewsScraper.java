package footsiebot.datagatheringcore;

public class NewsScraper {

  public NewsScraper() {
    
  }

  public Article[] scrapeNews(String company) {

  }

  public Article[] scrapeNews(String[] company) {

  }




}
