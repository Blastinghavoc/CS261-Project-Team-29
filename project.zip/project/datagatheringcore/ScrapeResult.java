package footsiebot.datagatheringcore;


public class ScrapeResult {
  private String[] codes;
  private String[] names;
  private String[] groups;
  private double[] prices;
  private double absChange;
  private double[] percChange;

  public ScrapeResult() {

  }

  public String getCode(int index) {

  }

  public String getName(int index) {

  }

  public String getGroup(int index) {

  }

  public double getPrice(int index) {

  }

  public double getAbsChange(int index) {

  }

  public double getPercChange(int index) {
    
  }










}
