package footsiebot.datagatheringcore;

public class WebScraper {

  public WebScraper() {
    
  }

  public ScrapeResult scrape() {

  }
}
