package footsiebot.guicore;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.shape.Rectangle;


public class GUIcore implements GraphicalUserInterface {


  private String style;
  private StackPane root;
  private Scene scene;
  private ScrollPane boardWrapper;
  private FlowPane messageBoard;
  private StackPane inputWrapper;
  private Rectangle inputVisual;
  private TextField input;

  public GUIcore(Stage primaryStage) {

  }

  public GUIcore(Stage primaryStage, String style) {

  }

  public void displayResults(String data, boolean isAI) {

  }


  public void displayResults(String[] news, boolean isAI) {

  }

  public void displayMessage(String msg) {

  }

  public setStyle(String style) {

  }

  private void onUserInput() {

  }

  private void setup() {
    
  }




}
