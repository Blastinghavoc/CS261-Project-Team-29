package footsiebot.guicore;

public interface GraphicalUserInterface {

  public void displayResults(String data, boolean isAI);

  public void displayResults(String[] news, boolean isAI);

}
