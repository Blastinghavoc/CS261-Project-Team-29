package footsiebot.GUIcore;

public class Message implements StackPane {

  private Label message;
  private DateTime timeStamp;
  private boolean sent;
  private Rectangle visual;

  public Label getLabel() {

  }

  public String getText() {

  }

  public boolean getSent() {

  }

  public DateTime getTimeStamp() {

  }


}
