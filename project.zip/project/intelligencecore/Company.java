package footsiebot.intelligencecore;


public class Company {

  private String code;
  private IntentData[] intents;
  private Intent topIntent;
  private float newsCounter;
  private float priority;
  private double irrelevantSuggestionWeight;


  public double getIrrelevantSuggestionWeight() {

  }

  public String getCode() {

  }

  public IntentData getTopIntentData() {

  }

  public float getNewsCount() {

  }

  public float getPriority() {

  }

  public void incrementPriority(double d) {
    pri
  }

  public void decrementPriority(double d) {
  }






}
