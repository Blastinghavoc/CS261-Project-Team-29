package footsiebot.intelligencecore;


public class Group {
  private ArrayList<Company> companies;
  private  String code;
  private float priority;
  private float irrelevantSuggestionWeight;


  public Group() {

  }

  public String getGroupCode() {

  }

  public float getPriority() {

  }

  public void incrementPriority() {

  }

  public void decrementPriority() {

  }




}
