package footsiebot.intelligencecore;


public interface IntelligenceUnit {



  
}
