package footsiebot.intelligencecore;

public class Suggestion {

  private String desc;
  private Company company;
  private boolean isNews;
  private String reason;


  public Suggestion(String d) {
    desc = d;
  }

  public void update() {

  }


  public Company getCompany() {

  }

  public boolean isNews() {

  }

  public String getSuggestion() {

  }

  public String getReason() {

  }





}
